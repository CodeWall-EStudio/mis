
// 主题管理员
exports.ROLE_SUBJECT_MANAGER = 1;

// 主题成员
exports.ROLE_SUBJECT_MEMBER = 2;

// 主题关联的标签
exports.LABEL_TYPE_SUBJECT = 1;

// 主题下的文章可以设置的标签
exports.LABEL_TYPE_SUBJECT_ARTICLE = 2;

// 文章关联的标签
exports.LABEL_TYPE_ARTICLE = 3;