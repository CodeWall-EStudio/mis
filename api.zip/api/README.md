# mis
Multimedia Interaction System API Server

# 安装 & 启动 redis(MAC)
    brew install redis

    redis-server /usr/local/etc/redis.conf

# 启动 server
    node --harmony app.js